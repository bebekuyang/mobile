class AppRoutes{
  static const homePage = "/";
  static const allTickets = "/all_tickets";
  static const ticketScreen = "/ticket_screen";
  static const allHotels = "/all_hotels";
  static const hotelDetail = "/hotel_detail";
}