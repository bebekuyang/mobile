// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bottom_nav_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$bottomNavBarNotifierHash() =>
    r'cdbb1cfac90af73dd0abc576b404261d7c5516c0';

/// See also [BottomNavBarNotifier].
@ProviderFor(BottomNavBarNotifier)
final bottomNavBarNotifierProvider =
    AutoDisposeNotifierProvider<BottomNavBarNotifier, int>.internal(
  BottomNavBarNotifier.new,
  name: r'bottomNavBarNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$bottomNavBarNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$BottomNavBarNotifier = AutoDisposeNotifier<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
