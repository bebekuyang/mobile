// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'text_expansion_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$textExpansionNotifierHash() =>
    r'2c1fda5458a1ca1467ac9e0b8604308c180614e9';

/// See also [TextExpansionNotifier].
@ProviderFor(TextExpansionNotifier)
final textExpansionNotifierProvider =
    AutoDisposeNotifierProvider<TextExpansionNotifier, bool>.internal(
  TextExpansionNotifier.new,
  name: r'textExpansionNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$textExpansionNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$TextExpansionNotifier = AutoDisposeNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
